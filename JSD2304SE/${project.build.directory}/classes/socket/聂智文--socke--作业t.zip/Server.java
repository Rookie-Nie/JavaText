package socket;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 聊天室服务端
 */

public class Server {
    /**
     *  java.net.ServerSocket
     *  ServerSocket主要有两个作用
     *  1:向系统申请服务端口,客户端就是通过这个端口与服务端建立连接的
     *  2:监听端口等待客户端的连接
     *    一旦一个客户端与服务端建立连接,此时会创建一个Socket与该客户端交互
     */
    private ServerSocket serverSocket;
    public Server(){
        try {
            System.out.println("正在启动服务端。。。");
            /*
                实例化ServerSocket时要指定服务端口,如果该端口已经被操作
                系统其他程序占用时会抛出异常:
                java.net.BingException():address already in use
             */
            serverSocket = new ServerSocket(8088);
            System.out.println("服务端启动完毕！");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void start(){
        try {
            System.out.println("等待客户端连接。。。");
            Socket socket = serverSocket.accept();
            System.out.println("一个客户端连接了！");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {
        Server server = new Server();
        server.start();
    }
}
