package homework.day05;

import java.io.InputStream;

public class scanner {
    public scanner(InputStream in) {
    }
}
