package birdboot.core;




import birdboot.http.HttpServletRequest;
import birdboot.http.HttpServletResponse;

import java.io.File;
import java.io.IOException;
import java.net.Socket;
import java.net.URISyntaxException;

public class ClientHandler implements Runnable{
    private Socket socket;

    public ClientHandler(Socket socket){
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            //1、解析请求
            HttpServletRequest request = new HttpServletRequest(socket);
            HttpServletResponse response = new HttpServletResponse(socket);
            //2、处理请求
            String path = request.getUri();
            System.out.println("请求路径："+path);
            File baseDir =new File(
                    ClientHandler.class.getClassLoader().getResource(".").toURI()
            );
            File staticFile = new File(baseDir,"static");
            File file = new File(staticFile,path);

            if (file.isFile()){
                response.setStatusCode(200);
                response.setStatusReason("OK");
                response.setContentFile(file);
            }else {
                response.setStatusCode(404);
                response.setStatusReason("NotFound");
                response.setContentFile(new File(staticFile,"404.html"));
            }


            //3、发送响应
            response.response();


        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
        }finally {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


}
