package socket;

import java.io.IOException;
import java.net.Socket;

/**
 * 聊天室客户端
 */
public class Client {
    /*
        java.net.Socket 套接字
        1该类封装了TCP协议的通讯细节,我们使用它可以与远端计算机建立连接并进行
        可靠的传输通讯.

     */
    private Socket socket;
    public Client(){
        try {
            System.out.println("正在连接服务端。。。。");
            /*
                Socket的实例化时需要传入两个参数:
                1:服务器的IP地址
                2:服务端应用程序打开的端口
                我们通过IP地址可以找到服务器在网络中的位置,通过端口找到运行在
                服务器上的服务端应用程序
             */
            socket = new Socket("localhost",8088);
            System.out.println("与服务器建立连接！");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void start(){}

    public static void main(String[] args) {
        Client client = new Client();//实例化客户端
        client.start();//启动客户端
    }
}
